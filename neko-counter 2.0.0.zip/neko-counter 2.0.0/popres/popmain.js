window.addEventListener("load", reload, false);

function reload(){
    console.log("reload");
    var lesson = ['哲学的人間学', '中国語', '教育学', '医学英語Ⅰ','地域医療学','免疫'];
    var lesson_num = [15,15,15,15,4,14];
    


    
    //FIXME:看護ようは作るか謎
    // 遅れてる科目チェックようボタン
    // var buttontxt = "<div><button id=\"complete_reload_button\">更新</button>一番遅れてる科目→<span id=\"behind_subject\">これ</span></div>";
    var buttontxt = "<div>一番目に遅れてる科目→<span id=\"behind_subject\">これ</span></div>";
    buttontxt += "<div>二番目に遅れてる科目→<span id=\"second_behind_subject\">これ</span></div>";
    buttontxt += "<div>三番目に遅れてる科目→<span id=\"third_behind_subject\">これ</span></div>";
    buttontxt += txt;
    var el = document.getElementById("nocontents");
    var element = document.getElementById("maincontents");
    if(element==null){
        el.insertAdjacentHTML("afterbegin",buttontxt);
    }else{
        //element.outerHTML = txt;
    }

    var targets = document.getElementsByClassName('lesson_check');
    for(let i = 0; i < targets.length; i++){
      targets[i].addEventListener('change', save);
    }
    // var complete_button_elm = document.getElementById('complete_reload_button');
    // complete_button_elm.addEventListener('click', completecheck);
    completecheck();
  }

  function save(lesson) {
    var key = lesson.srcElement.dataset.savekey;
    var value = lesson.target.checked
    localStorage.setItem(key,value);
    console.log(key+":"+value+"saved");
    // reload();
    completecheck();
  }

  function completecheck(){
      for(let i=0;i<lesson_title.length;i++){
        var elms = document.getElementsByClassName(lesson_title[i]);
        var complete= 0;
        for(let j=0;j<elms.length;j++){
            if(elms[j].checked){
                complete+=1;
            }
        }
        lesson_complete[i]=complete;
      }   
      console.log(lesson_complete);
      var elm = document.getElementById("behind_subject");
      var elm2 = document.getElementById("second_behind_subject");
      var elm3 = document.getElementById("third_behind_subject");
      var ratio=[0,0,0,0,0,0,0,0,0,0,0,0,0];
      var min_ratio=100;
      var min_index = 0;
      for(let k=0;k<ratio.length;k++){
          ratio[k]=lesson_complete[k]*100/(lesson_num[k]+1);
          if(min_ratio>ratio[k]){
              min_ratio = ratio[k];
              min_index = k;
          }
      }
      elm.innerHTML=lesson_title[min_index];

    var min_ratio=100;
    var second_min_index=0;

    for(let k=0;k<ratio.length;k++){
        if(k==min_index){//1番目は除く
            continue;
        }else{
            if(min_ratio>ratio[k]){
                min_ratio = ratio[k];
                second_min_index =k;
            }
        }
    }
    elm2.innerHTML=lesson_title[second_min_index];
        


    var min_ratio=100;
    var third_min_index=0;

    for(let k=0;k<ratio.length;k++){
        if(k==min_index||k==second_min_index){//1番目は除く
            continue;
        }else{
            if(min_ratio>ratio[k]){
                min_ratio = ratio[k];
            third_min_index =k;
            }
        }
    }
      
    elm3.innerHTML=lesson_title[third_min_index];
  }


